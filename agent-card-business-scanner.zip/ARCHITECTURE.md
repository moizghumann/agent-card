# Architecture Note

## Scan Flow

The app runs an Express server with a static frontend. `POST /api/analyze` accepts a public URL and calls `analyzeBusinessUrl()`.

The scanner normalizes the URL, blocks private hosts, fetches HTML pages with a timeout, and crawls same-site links up to a page limit. It prioritizes likely business pages such as contact, pricing, services, products, about, menu, shop, booking, support, and FAQ. For each page it extracts titles, meta descriptions, headings, visible text, links, buttons, forms, and basic JSON-LD fields.

## Business Map Creation

`createBusinessMap()` turns crawl output into structured observations:

- pages found and whether each was scanned
- business name, description, and likely type
- products or services inferred from headings and relevant snippets
- customer actions inferred from links, buttons, and forms
- tools/forms/links such as contact forms, auth links, booking links, carts, checkout, social links
- visible contact, payment, auth, location, and hours signals
- missing or unclear facts

Each important finding stores evidence IDs. The evidence index contains a source URL and short quote. If the scanner cannot prove something, it leaves the field unknown or adds a missing/unclear note.

When `OPENROUTER_API_KEY` is configured, `enhanceBusinessMapWithLlm()` sends the deterministic map and evidence index to OpenRouter for refinement. The LLM is constrained to keep the same business-map shape, cite existing evidence IDs, and mark unsupported facts as unknown. A sanitizer rejects evidence IDs that do not exist and falls back to deterministic values when the model output is malformed.

## Agent Card Generation

`generateAgentCard()` only reads the business map. It does not rescan pages and does not invent capabilities. Customer actions become agent capabilities only when the business map found supporting evidence. The card also includes source evidence, unknowns, recommended follow-up questions, and a safe automation policy requiring human approval for form submission, purchase, account creation, payment, or message sending.

When OpenRouter is configured, `generateAgentCardWithOptionalLlm()` asks the model to create the final card from the refined business map and a deterministic baseline schema. A sanitizer keeps the evidence index from the map, blocks capabilities that were not present in the map, and preserves the human-approval safety policy.

## Deterministic Code vs LLMs

The implementation is deterministic-first:

- crawling, page selection, parsing, evidence extraction, map construction, and card generation are all code-based
- no LLM is required to run the app
- OpenRouter is optional and receives only already-extracted map/evidence data
- model output is sanitized against the evidence index before it reaches the UI

The intended contract is: deterministic code gathers evidence, the LLM may improve organization and phrasing, and validation prevents unevidenced claims from becoming agent capabilities.

## Where MCP / Tools Fit Later

MCP tools would fit as capability adapters around the agent card:

- browser automation for deeper interactive flows, screenshots, and client-rendered pages
- search tools for discovering official profiles or docs when the site is sparse
- payment, CRM, calendar, email, or support tools for verified downstream actions
- structured extraction tools for PDFs, menus, product catalogs, and schema validation

The card should remain the contract: tools may enrich evidence, but downstream capabilities stay unavailable until the map proves them.

## Next 7 Days

1. Add a JSON Schema for the business map and agent card, with validation in API responses.
2. Support JavaScript-rendered sites with a headless browser fallback.
3. Add robots.txt awareness, crawl politeness, and clearer scan diagnostics.
4. Improve offering extraction with page-section context instead of headings alone.
5. Add optional LLM summarization constrained to evidence IDs.
6. Build regression tests using saved HTML fixtures from varied business types.
7. Add export buttons for map JSON, card JSON, and a human-readable evidence report.
